@extends('layouts.adminLayout.backendLayout')
@section('content')
<?php use App\FileDropdown; use App\Employee; use App\File;?>
<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-head">
            <div class="page-title">
                <h1>File's Management </h1>
            </div>
        </div>
        <ul class="page-breadcrumb breadcrumb">
            <li>
                <a href="{!! action('AdminController@dashboard') !!}">Dashboard</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <a href="{{ action('FileController@files') }}">Files</a>
            </li>
        </ul>
        <div class="row">
            <div class="col-md-12 ">
                <div class="portlet blue-hoki box ">
				    <div class="portlet-title">
				        <div class="caption">
				            <i class="fa fa-gift"></i>{{$title}}
				        </div>
				    </div>
				    <div class="portlet-body form">
				        <form  class="form-horizontal" method="get" action="{{url('/s/admin/add-file')}}">@csrf
				        	<div class="form-body">
				                <div class="row">
                        			<div class="form-group">
			                            <label class="col-md-3 control-label">Select Client:</label>
			                            <div class="col-md-4">
			                                <select name="client_id" class="selectpicker form-control getfileNo" required data-live-search="true" data-size="7" data-width="100%"> 
			                                    <option value="">Select</option>
			                                    @foreach($clients as $client)
													<option value="{{$client['id']}}" @if(isset($_GET['client_id']) && $_GET['client_id']==$client['id'])  selected @endif>{{$client['client_id']}} ({{$client['name']}}-{{$client['mobile']}}-{{$client['pan']}})</option>
			                                    @endforeach
			                                </select>
			                            </div>
			                       	</div>
				                </div>
				            </div>
				            <div class="form-actions right1 text-center">
				                <button class="btn green" type="submit">Go</button>
				            </div>
				        </form>
				    </div>
				</div>
				@if($clientdetail)	
					<div class="portlet-body">
	                    <div class="row">
	                        <div class="col-md-12 col-sm-12">
	                            <div class="portlet blue-hoki box">
	                                <div class="portlet-title">
	                                    <div class="caption">
	                                        <i class="fa fa-cogs"></i>Files of {{$clientdetail->name}}
	                                    </div>
	                                	<a target="_blank" class="btn btn-sm grey pull-right" style="margin-top: 7px;" href="{{url('/s/admin/generate-file/'.$clientdetail->id)}}">Generate new File for {{$clientdetail->name}}</a>
	                                </div>
	                                <div class="portlet-body">
	                                    <div class="table-responsive">
	                                        <table class="table table-hover table-bordered table-striped">
	                                            <thead>
	                                                <tr>
	                                                    <th>
	                                                        File No
	                                                    </th>
	                                                    <th>
	                                                        Facility Type
	                                                    </th>
	                                                    <th>
	                                                        Business Manager
	                                                    </th>
	                                                    <th>
	                                                        File Creation Date
	                                                    </th>
	                                                    <th>
	                                                        Actions
	                                                    </th>
	                                                </tr>
	                                            </thead>
	                                            <tbody>
	                                                @if(!empty($clientfiles))
	                                                    @foreach($clientfiles as $file)
	                                                        <tr>
	                                                            <td><a target="_blank" title="View Details" class="btn btn-sm blue" href={{url('/s/admin/create-applicants/'.$file['id'].'?open=modal')}}>{{$file['file_no']}}</a></td>
	                                                            <td>
	                                                                {{$file['facility_type']}}
	                                                            </td>
	                                                            <?php $getbm = Employee::getemployee($file['business_manager_id']);?>
	                                                            <td>
	                                                                {{$getbm['name']}}
	                                                            </td>
	                                                            <td>
	                                                            {{date('d M Y',strtotime($file['created_at']))}}</td>
	                                                            <td><a target="_blank" title="View Details" class="btn btn-sm green" href="{{url('/s/admin/generate-file/'.$file['client_id'].'?fileid='.$file['id'])}}">Copy</a></td>
	                                                        </tr>
	                                                    @endforeach
	                                                @else
	                                                <tr>
	                                                    <td colspan="5" style="text-align: center">
	                                                        No Files found.
	                                                    </td>
	                                                </tr>
	                                                @endif
	                                            </tbody>
	                                        </table>
	                                    </div>
	                                </div>
	                            </div>
	                        </div>
	                    </div>
	                </div>
                @endif
            </div>
        </div>
    </div>
</div>
@stop
@extends('layouts.adminLayout.backendLayout')
@section('content')
<?php use App\Bank; use App\FileDropdown; use App\FileLoanDetail;
$banks = Bank::banks();
$types = FileDropdown::getfiledropdown('facility');?>
<style>
	td,th{position: relative;}
</style>
<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-head">
            <div class="page-title">
                <h1>File's Management </h1>
            </div>
        </div>
        <ul class="page-breadcrumb breadcrumb">
            <li>
                <a href="{!! action('AdminController@dashboard') !!}">Dashboard</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
            	<a href="{{url('/s/admin/create-applicants/'.$fileid)}}">Files</a>
            	<i class="fa fa-circle"></i>
            </li>
            <li>
            	<a class="green btn" href="{{url('/s/admin/create-applicants/'.$fileid)}}">Back</a>
            </li>
        </ul>
        @if(Session::has('flash_message_success'))
            <div role="alert" class="alert alert-success alert-dismissible fade in"> <button aria-label="Close" data-dismiss="alert" style="text-indent: 0;" class="close" type="button"><span aria-hidden="true"></span></button> <strong>Success!</strong> {!! session('flash_message_success') !!} </div>
        @endif
        <div class="row">
            <div class="col-md-12">
                <div class="portlet blue-hoki box ">
				    <div class="portlet-title">
				        <div class="caption">
				            <i class="fa fa-gift"></i>{{$title}}
				        </div>
				    </div>
				    <div class="portlet-body form">
				        <form action="{{url('/s/admin/add-loan-details/'.$fileid)}}"  class="fullWidth" method="post" enctype="multipart/form-data" autocomplete="off">@csrf
				        	<div class="form-body tableWrapper--main">
							    <div class="fullWidth text-left tableFlow">
							        <table class="table table-bordered table-condensed table--main" valign="top">
							        	<thead>
								        	<tr>
									        	<th data-no>Sr. No.</th>
									        	<th data-lan>LAN</th>
									        	<th data-customerName>Customer Name</th>
									        	<th data-bank>Bank Name</th>
									        	<th data-type>Type</th>
									        	<th data-loan-amt>Loan Amt.</th>
									        	<th data-tenure>Tenure ( in Months )</th>
									        	<th data-loan-start-date>EMI Start Date</th>
									        	<th data-paid-installments>No of Installment. Paid</th>
									        	<th data-balance-installments>No. if Installment. Balance</th>
									        	<th data-emi-amt>EMI Amt</th>
									        	<th data-foir>FOIR</th>
									        	<th data-action class="text-center">Actions</th>
									        </tr>
							        	</thead>
							        	<tbody>
											@if(!empty($loandetails))
												@foreach($loandetails as $lkey => $loandetail)
													<input type="hidden" name="loan_id[]" value="{{$loandetail['id']}}">
													<tr data-row>
											        	<td data-no class="text-center">{{++$lkey}}</td>
											        	<td data-lan>
											        		<input type="text" required class="form-control" name="lan[]" placeholder="Enter LAN" value="{{$loandetail['lan']}}"/>
											        	</td>
											        	<td data-customerName>
											        		<input type="text" required class="form-control" name="customer_name[]"placeholder="Customer Name" value="{{$loandetail['customer_name']}}"/>
											        	</td>
											        	<td data-bank>
											        		<select id="" required class="form-control" name="bank_name[]">
											        			<option value="" selected="selected">Select Bank</option>
											        			@foreach($banks as $bank)
											        				<option value="{{$bank['short_name']}}" @if($bank['short_name'] == $loandetail['bank_name']) selected="" @endif>{{$bank['short_name']}}</option>
											        			@endforeach
											        		</select>
											        	</td>
											        	<td data-type>
											        		<select name="type[]" id="" required class="form-control">
											        			<option value="" selected="selected">Select Type</option>
											        			@foreach($types as $type)
											        				<option value="{{$type['value']}}" @if($type['value'] == $loandetail['type']) selected="" @endif>{{$type['value']}}</option>
											        			@endforeach
											        		</select>
											        	</td>
											        	<td data-loan-amt>
											        		<input type="number" placeholder="Loan Amount" required class="form-control" name="loan_amt[]" value="{{$loandetail['loan_amt']}}" />
											        	</td>
											        	<td data-tenure>
											        		<input type="number" required class="form-control" name="tenure_in_months[]" placeholder="Tenure"  value="{{$loandetail['tenure_in_months']}}"/>
											        	</td>
											        	<td data-loan-start-date>
											        		<div class="fullWidth">
											        			<input type="text"   required class="form-control dobDatepicker__table" name="emi_start_date[]" placeholder="Loan Start Date" value="{{$loandetail['emi_start_date']}}" />
											        		</div>
											        	</td>
											        	<td data-paid-installments>
											        		<input type="number" required class="form-control" name="no_of_installment_paid[]" placeholder="Paid Installments" value="{{$loandetail['no_of_installment_paid']}}" />
											        	</td>
											        	<td data-balance-installments>
											        		<input type="number" required class="form-control" name="no_of_installment_balance[]" placeholder="Balance Installments" value="{{$loandetail['no_of_installment_balance']}}" />
											        	</td>
											        	<td data-emi-amt>
											        		<input type="number" required class="form-control" name="emi_amt[]" placeholder="Emi Amount" value="{{$loandetail['emi_amt']}}"/>
											        	</td>
											        	<td data-foir>
											        		<select id="" required class="form-control" name="foir[]">
											        			<option value="No" @if('No' == $loandetail['foir']) selected="" @endif>
											        				No
											        			</option>
											        			<option value="Yes" @if('Yes' == $loandetail['foir']) selected="" @endif>Yes</option>
											        		</select> 
											        	</td>
											        	<td data-action>
											        		<div class="fullWidth text-center">
											        			<a href="javascript:void(0);" class="btn btn-danger deleteRowBtn" style="display: none;">
											        				<span class="glyphicon glyphicon-remove"></span>
											        			</a>		
											        		</div>	
											        	</td>
									        		</tr>
												@endforeach
											@else
												<tr data-row>
										        	<td class="text-center" data-no>1</td>
										        	<td data-lan>
										        		<input type="text" required class="form-control" name="lan[]" placeholder="Enter LAN" />
										        	</td>
										        	<td data-customerName>
										        		<input type="text" required class="form-control" name="customer_name[]"placeholder="Customer Name" />
										        	</td>
										        	<td data-bank>
										        		<select id="" required class="form-control" name="bank_name[]">
										        			<option value="" selected="selected">Select Bank</option>
										        			@foreach($banks as $bank)
										        				<option value="{{$bank['short_name']}}">{{$bank['short_name']}}</option>
										        			@endforeach
										        		</select>
										        	</td>
										        	<td data-type>
										        		<select name="type[]" id="" required class="form-control">
										        			<option value="" selected="selected">Select Type</option>
										        			@foreach($types as $type)
										        				<option value="{{$type['value']}}">{{$type['value']}}</option>
										        			@endforeach
										        		</select>
										        	</td>
										        	<td data-loan-amt>
										        		<input type="number" placeholder="Loan Amount" required class="form-control" name="loan_amt[]" />
										        	</td>
										        	<td data-tenure>
										        		<input type="number" required class="form-control" name="tenure_in_months[]" placeholder="Tenure" />
										        	</td>
										        	<td data-loan-start-date>
										        		<div class="fullWidth">
										        			<input type="text" required class="form-control dobDatepicker__table" name="emi_start_date[]" placeholder="Loan Start Date" />
										        		</div>
										        	</td>
										        	<td data-paid-installments>
										        		<input type="number" required class="form-control" name="no_of_installment_paid[]" placeholder="Paid Installments" />
										        	</td>
										        	<td data-balance-installments>
										        		<input type="number" required class="form-control" name="no_of_installment_balance[]" placeholder="Balance Installments" />
										        	</td>
										        	<td data-emi-amt>
										        		<input type="number" required class="form-control" name="emi_amt[]" placeholder="Emi Amount" />
										        	</td>
										        	<td data-foir>
										        		<select id="" required class="form-control" name="foir[]">
										        			<option value="No">
										        				No
										        			</option>
										        			<option value="Yes">Yes</option>
										        		</select> 
										        	</td>
										        	<td data-action>
										        		<div class="fullWidth text-center">
										        			<a href="javascript:void(0);" class="btn btn-danger deleteRowBtn">
										        				<span class="glyphicon glyphicon-remove"></span>
										        			</a>		
										        		</div>
										        	</td>
										        </tr>
										    @endif
							        	</tbody>
							        </table>
							    </div>
				            </div>
				            @if(!empty($totalemiamt))
					            <h3 class="fullWidth text-right" style="padding: 10px 15px; background-color: #fff;">
					            	Total: <span style="display:inline-block;margin-left:10px;font-weight:bold;">
					            		{{FileLoanDetail::format($totalemiamt)}}
					            	</span>
					            </h3>
					        @endif
				            <div class="form-actions right1 text-center">
				                <button class="btn green" type="submit">Submit</button>
			        			<a href="javascript:void(0);" class="btn btn-primary addRowBtn pull-right">
			        				Add Row
			        			</a>
				            </div>
				        </form>
				    </div>
				</div>
            </div>
        </div>
    </div>
</div>
<script>
	window.addEventListener('DOMContentLoaded', function () {
	    $('.dobDatepicker__table').datetimepicker({
	        format:'YYYY-MM-DD',
	        useCurrent: false,
	        allowInputToggle: true
	    });
	    funcDateTimecalc();
		$('.table--main').find('td[data-loan-start-date]').each(function (index) {
			$(this).attr('id', 'datetimepickerTd-' + (index+1));
		});
		$('.table--main').find('td[data-loan-start-date]').each(function (index) {
			$(this).find('input').on('focus', function () {
				$(this).closest('.tableWrapper--main').css({
					'padding-bottom': '200px'
				});
				$('.tableFlow').scrollLeft($('[data-loan-start-date]').first().position().left);
				$(this).closest('.tableFlow').children('table').css({
					'margin-bottom': '305px' 
				});
			});
			$(this).find('input').on('blur', function () {
				$(this).closest('.tableFlow').attr('style','');
				$(this).closest('.tableFlow table').attr('style','');
				$(this).closest('.tableWrapper--main').attr('style','');
			});
		});
		$('.addRowBtn').on('click', function (e) {
			e.preventDefault();
			$('.table--main').find('tr[data-row]').first().attr('data-row', '');
			var cloned = $('.table--main').find('tr[data-row]').first().clone();
			$('.table--main').find('tbody').append(cloned);
			$('[data-row]').each(function (index) {
				$(this).attr('data-row', (index + 1));
				$(this).find('td[data-no]').html(index + 1);
			});			
			$('tr[data-row]:last-of-type').find('input.form-control').each(function () {
				$(this).val('');
			});		
			$('tr[data-row]:last-of-type').find('select.form-control').each(function () {
				$(this).find('option:first-of-type').attr('selected');
				$(this).find('option:first-of-type').siblings().removeAttr('selected');
			});
			$('tr[data-row]:last-of-type').find('a.deleteRowBtn').attr('style', ' ');
			$('.dobDatepicker__table').datetimepicker({
		        format:'YYYY-MM-DD',
		        useCurrent: false,
		        allowInputToggle: true
		    });
		    funcDateTimecalc();
			$('.table--main').find('td[data-loan-start-date]').each(function (index) {
				$(this).find('input').on('focus', function () {
					$(this).closest('.tableWrapper--main').css({
						'padding-bottom': '200px'
					});
					
					$(this).closest('.tableFlow').children('table').css({
						'margin-bottom': '305px' 
					});
				});
				$(this).find('input').on('blur', function () {
					$(this).closest('.tableFlow').attr('style','');
					$(this).closest('.tableFlow table').attr('style','');
					$(this).closest('.tableWrapper--main').attr('style','');
				});
			});
		});
		$(document).on('click', '.deleteRowBtn' , function (e) {
			e.preventDefault();		
			if ($(this).closest('tr[data-row]').is(':only-child')) {
				alert('You can not remove all rows');
			}
			$(this).closest('tr[data-row]:not(:only-child)').remove();
			$('[data-row]').each(function (index) {
				$(this).attr('data-row', (index + 1));
				$(this).find('td[data-no]').html(index + 1);
			});	
		});
	});
	function funcDateTimecalc () {
		$('.dobDatepicker__table').each(function (key) {
			$(this).attr('data-id', 'dateTimePicker-' + key);
		});
		var idsDateTimePicker = $('.dobDatepicker__table').map(function (key) {
			return $(this).attr('data-id');
		}).get();
		for (var i = 0; i<idsDateTimePicker.length; i++) {
			$('[data-id="dateTimePicker-' + i + '"]').on("dp.change", function (e) {
				var $this = $(this);
				var date = $this.data('date');
				var $target = $this.closest('td').siblings('td[data-tenure]').find('input');
				var tenure = $target.val();
				if($target.val().length > 0) {
					$.ajax({
						url: '/s/admin/calculate-installments',
						data: {emidate: date, tenure:tenure},
						type: 'POST',
						success:function (resp) {
							var r = parseInt(resp['diff']);
							var diff = parseInt(resp['tenure']);
							$this.closest('td').siblings('td[data-paid-installments]').find('input').val(r);
							$this.closest('td').siblings('td[data-balance-installments]').find('input').val(diff);
						},
						error: function () {
							alert("error");
						}
					})
				} else {
					alert('Please enter value of Tenure (in months)');
				}	
			});
		 } 
	}
</script>	
@stop
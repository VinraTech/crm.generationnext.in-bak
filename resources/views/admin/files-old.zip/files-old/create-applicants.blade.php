@extends('layouts.adminLayout.backendLayout')
@section('content')
<?php use App\FileDropdown; use App\Employee; use App\ChannelPartner; use App\Client; ?>
<style>
.table-scrollable table tbody tr td{
    vertical-align: middle;
}
</style>
<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-head">
            <div class="page-title">
                <h1>File's Management</h1>
            </div>
        </div>
       <ul class="page-breadcrumb breadcrumb">
            <li>
                <a href="{!! action('AdminController@dashboard') !!}">Dashboard</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <a href="{{ action('FileController@files') }}">Files</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <a class="btn green" href="{{ action('FileController@files') }}">Back</a>
            </li>
        </ul>
         @if(Session::has('flash_message_error'))
            <div role="alert" class="alert alert-danger alert-dismissible fade in"> <button aria-label="Close" data-dismiss="alert" style="text-indent: 0;" class="close" type="button"><span aria-hidden="true"></span></button> <strong>Error!</strong> {!! session('flash_message_error') !!} </div>
        @endif
        @if(Session::has('flash_message_success'))
            <div role="alert" class="alert alert-success alert-dismissible fade in"> <button aria-label="Close" data-dismiss="alert" style="text-indent: 0;" class="close" type="button"><span aria-hidden="true"></span></button> <strong>Success!</strong> {!! session('flash_message_success') !!} </div>
        @endif
        <div class="row">
            <div class="col-md-12">
                <div class="portlet light">
                    <div class="portlet-title">
                        <div class="caption">
                            <span class="caption-subject font-green-sharp bold uppercase">Create Applicants ({{$filedetails['file_no']}})</span>
                        </div>
                    </div>
                    <div class="portlet-body">
                         <div class="table-toolbar">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="btn-group">
                                    	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#ViewFileData">View File Details</button>
                                    </div>
                                    @if($applicantAccess == "yes")
	                                    <div class="btn-group">
	                                    	<a href="{{url('/s/admin/add-individual-applicant/'.$filedetails['id'])}}" class="btn btn-primary">Add Indvidual Applicant</a>
	                                    </div>
	                                    <div class="btn-group">
	                                    	<a href="{{url('/s/admin/add-non-individual-applicant/'.$filedetails['id'])}}" class="btn btn-primary">Add Non-Indvidual Applicant</a>
	                                    </div> 
	                                    <div class="btn-group">
	                                    	<a href="{{url('/s/admin/add-facility-requirement/'.$filedetails['id'])}}" class="btn btn-primary">Facility Requirement</a>
	                                    </div> 
	                                    <div class="btn-group">
	                                    	<a href="{{url('/s/admin/add-property-detail/'.$filedetails['id'])}}" class="btn btn-primary">Add Property Details</a>
	                                    </div>
	                                    <div class="btn-group">
	                                    	<a href="{{url('/s/admin/add-reference/'.$filedetails['id'])}}" class="btn btn-primary">Add Reference</a>
	                                    </div>
	                                @endif
                                </div>
                                @if($applicantAccess == "yes")
	                                <div class="clearfix"></div><br>
	                                <div class="col-md-12">
		                                <div class="btn-group">
		                                    <a href="{{url('s/admin/update-financial-details/'.$filedetails['id'])}}" class="btn btn-primary">Financial Details</a>
		                                </div>
	                                	<div class="btn-group">
	                                    	<a href="{{url('s/admin/add-loan-details/'.$filedetails['id'])}}" class="btn btn-primary">Add Loan Details</a>
	                                    </div>
	                                </div>
	                            @endif
                            </div>
                        </div>
                        <div class="table-container">
							<table class="table table-striped table-bordered table-hover" >
								  <caption><b>Individual Applicants</b></caption>
							    <thead>
							        <tr>
							        	<th>
							                Sr No.
							            </th>
							            <th>
							                Name
							            </th>
							            <th>
							               UID
							            </th>
							            <th>
							               Residental Status
							            </th>
							            <th>
							               Nationality
							            </th>
							            <th>
							               Occupation
							            </th>
							            <th>
							               Tel No
							            </th>
							            <th>
							               Mobile No
							            </th>
							            <th>
							               Actions
							            </th>
							        </tr>
								    <tbody>
								    	@foreach($getIndApplicants as $ikey=> $iapplicant)
									    	<tr>
									    		<td>{{++$ikey}}</td>
									    		<td>{{$iapplicant['name']}}</td>
									    		<td>{{$iapplicant['uid']}}</td>
									    		<td>{{$iapplicant['residental_status']}}</td>
									    		<td>{{$iapplicant['nationality']}}</td>
									    		<td>{{$iapplicant['occupation']}}</td>
									    		<td>{{$iapplicant['tel_no']}}</td>
									    		<td>{{$iapplicant['mobile_no']}}</td>
									    		<td>
									    			@if($applicantAccess == "yes")
									    				<a title="Edit Applicant" class="btn btn-sm green" href="{{url('/s/admin/add-individual-applicant/'.$filedetails['id'].'/'.$iapplicant['id'])}}"> <i class="fa fa-edit"></i></a>
									    			@endif
									    		</td>
									    	</tr>
									    @endforeach
								    </tbody>
							</table>
                        </div>
                        <div class="table-container">
							<table class="table table-striped table-bordered table-hover" >
								  <caption><b>Non Individual Applicants</b></caption>
							    <thead>
							        <tr>
							        	<th>
							                Sr No.
							            </th>
							            <th>
							                Company Name
							            </th>
							            <th>
							               Company Type
							            </th>
							            <th>
							               Nature of Business
							            </th>
							            <th>
							               District
							            </th>
							            <th>
							               City
							            </th>
							            <th>
							               Tel No
							            </th>
							            <th>
							               Mobile No
							            </th>
							            <th>
							               Actions
							            </th>
							        </tr>
								    <tbody>
								    	@foreach($getNonIndApplicants as $nkey=> $nonapplicant)
									    	<tr>
									    		<td>{{++$nkey}}</td>
									    		<td>{{$nonapplicant['company_name']}}</td>
									    		<td>{{$nonapplicant['company_type']}}</td>
									    		<td>{{$nonapplicant['nature']}}</td>
									    		<td>{{$nonapplicant['district']}}</td>
									    		<td>{{$nonapplicant['city']}}</td>
									    		<td>{{$nonapplicant['tel_no']}}</td>
									    		<td>{{$nonapplicant['mobile_no']}}</td>
									    		<td>
									    			@if($applicantAccess == "yes")
									    				<a title="Edit Non Indvidual Applicant" class="btn btn-sm green" href="{{url('/s/admin/add-non-individual-applicant/'.$filedetails['id'].'/'.$nonapplicant['id'])}}"> <i class="fa fa-edit"></i></a>
									    			@endif
									    		</td>
									    	</tr>
									    @endforeach
								    </tbody>
							</table>
                        </div>
                        <div class="table-container">
							<table class="table table-striped table-bordered table-hover" >
								  <caption><b>Property Details</b></caption>
							    <thead>
							        <tr>
							        	<th>
							                Sr No.
							            </th>
							            <th>
							                Property Title
							            </th>
							            <th>
							               Address
							            </th>
							            <th>
							               Area
							            </th>
							            <th>
							               Valuations
							            </th>
							            <th>
							               Actions
							            </th>
							        </tr>
								    <tbody>
								    	@foreach($getpropertyDetails as $pkey=> $property)
									    	<tr>
									    		<td>{{++$pkey}}</td>
									    		<td>{{$property['property_title']}}</td>
									    		<td>{{$property['address']}}</td>
									    		<td>{{$property['land_area']}}</td>
									    		<td>@if(!empty($filedetails['filebanks']))
														<a data-fileid="{{$filedetails['id']}}" data-propertyid="{{$property['id']}}" title="Update Valuations" class="btn btn-sm blue updateValuations" href="javascript:;">View & Update Valuations</a>
													@endif
												</td>
									    		<td>
									    			@if($applicantAccess == "yes")
									    				<a title="Edit Property Detail" class="btn btn-sm green" href="{{url('/s/admin/add-property-detail/'.$filedetails['id'].'/'.$property['id'])}}"> <i class="fa fa-edit"></i></a>
													@endif
													
									    		</td>
									    	</tr>
									    @endforeach
								    </tbody>
							</table>
                        </div>
                        <div class="table-container">
							<table class="table table-striped table-bordered table-hover" >
								  <caption><b>Reference Details</b></caption>
							    <thead>
							        <tr>
							        	<th>
							                Sr No.
							            </th>
							            <th>
							                Name
							            </th>
							            <th>
							               Address
							            </th>
							            <th>
							               Pin
							            </th>
							            <th>
							               Tel No
							            </th>
							            <th>
							               Mobile No.
							            </th>
							            <th>
							               Relationship
							            </th>
							            <th>
							               Actions
							            </th>
							        </tr>
								    <tbody>
								    	@foreach($filerefers as $rkey=> $filerefer)
									    	<tr>
									    		<td>{{++$rkey}}</td>
									    		<td>{{$filerefer['name']}}</td>
									    		<td>{{$filerefer['address']}}</td>
									    		<td>{{$filerefer['pin']}}</td>
									    		<td>{{$filerefer['tel_no']}}</td>
									    		<td>{{$filerefer['mobile_no']}}</td>
									    		<td>{{$filerefer['relationship']}}</td>
									    		<td>
									    			@if($applicantAccess == "yes")
									    				<a title="Edit Reference" class="btn btn-sm green" href="{{url('/s/admin/add-reference/'.$filedetails['id'].'/'.$filerefer['id'])}}"> <i class="fa fa-edit"></i></a>
													@endif
									    		</td>
									    	</tr>
									    @endforeach
								    </tbody>
							</table>
                        </div>
                    </div>
                </div>
            	<div class="form-actions right1 text-center">
                	<a href="{{url('s/admin/add-checklist/'.$filedetails['id'])}}" class="btn btn-primary">Update Checklist</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- View File Details -->
<div class="modal fade" id="ViewFileData" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
                <h5 class="modal-title" id="exampleModalLabel">View File Details</h5>
            </div>
            <div class="modal-body">
                <table class="table table-bordered table-striped text-center">
					<tbody>
						<tr>
							<td>
								 File Number
							</td>
							<td>
								{{$filedetails['file_no']}}
							</td>
						</tr>
						<?php $clientdetails = Client::clientdetails($filedetails['client_id']) ?>
						<tr>
							<td>
								 Name
							</td>
							<td>
								{{$clientdetails['name']}}
							</td>
						</tr>
						<tr>
							<td>
								 Mobile
							</td>
							<td>
								{{$clientdetails['mobile']}}
							</td>
						</tr>
						<tr>
							<td>
								 PAN
							</td>
							<td>
								{{$clientdetails['pan']}}
							</td>
						</tr>
						<tr>
							<td>
								 Facility Type
							</td>
							<td>
								{{$filedetails['facility_type']}}
							</td>
						</tr>
						<tr>
							<td>
								 Amount Requested (Loan Amt.)
							</td>
							<td>
								@if(!empty($filedetails['amount_requested']))
									{{$filedetails['amount_requested']}}
								@else
									Not Entered Yet
								@endif
							</td>
						</tr>
						<?php $getbm = Employee::getemployee($filedetails['business_manager_id']) ?>
						<tr>
							<td>
								 Business Manager
							</td>
							<td>
								{{$getbm['name']}} - {{$getbm['emptype']}}
							</td>
						</tr>
						<?php $getsm = Employee::getemployee($filedetails['sales_manager_id']) ?>
						<tr>
							<td>
								 Sales Manager
							</td>
							<td>
								{{$getsm['name']}} - {{$getsm['emptype']}}
							</td>
						</tr>
						<?php $getse = Employee::getemployee($filedetails['sales_executive_id']) ?>
						<tr>
							<td>
								 Sales Executive
							</td>
							<td>
								{{$getse['name']}} - {{$getse['emptype']}}
							</td>
						</tr>
						<?php $getom = Employee::getemployee($filedetails['operation_manager_id']) ?>
						<tr>
							<td>
								 Operation Manager
							</td>
							<td>
								{{$getom['name']}} - {{$getom['emptype']}}
							</td>
						</tr>
						<?php $getoe = Employee::getemployee($filedetails['operation_executive_id']) ?>
						<tr>
							<td>
								 Operation Executive
							</td>
							<td>
								{{$getoe['name']}} - {{$getoe['emptype']}}
							</td>
						</tr>
						<?php $source = Employee::getemployee($filedetails['source']) ?>
						<tr>
							<td>
								Source
							</td>
							<td>
								{{$source['name']}} - {{$source['emptype']}}
							</td>
						</tr>
						<tr>
							<td>
								File Type
							</td>
							<td>
								{{ucwords($filedetails['file_type'])}}
							</td>
						</tr>
						@if($filedetails['file_type'] =="indirect")
							<?php $crm = Employee::getemployee($filedetails['crm_id']) ?>
							<tr>
								<td>
									Channel Relation Manager
								</td>
								<td>
									{{$crm['name']}} - {{$crm['emptype']}}
								</td>
							</tr>
							<?php $partner = ChannelPartner::partnerdetail($filedetails['channel_partner_id']) ?>
							<tr>
								<td>
									Channel Partner
								</td>
								<td>
									{{$partner['name']}} - {{$crm['type']}}
								</td>
							</tr>
						@endif
					</tbody>
				</table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<!-- View File Details -->

<!-- Valuation Modal -->
<div class="modal fade" id="ValuationModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
                <h5 class="modal-title" id="exampleModalLabel">Enter Valuation Details</h5>
            </div>
            <form action="{{url('/s/admin/update-valuations')}}" method="post" autocomplete="off">@csrf
	            <div class="modal-body">
	                <table class="table table-bordered table-striped text-center">
	                	<thead>
	                		<th width="30%">Bank</th>
	                		<th>Val-1</th>
	                		<th>Val-2</th>
	                	</thead>
		                <tbody id="AppendValuationModal">
		                	
		                </tbody>
	                </table>
	            </div>
	            <div class="modal-footer">
	                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	                <button type="submit" class="btn btn-primary">Submit</button>
	            </div>
            </form>
        </div>
    </div>
</div>
<!-- Valuation Modal -->
<script type="text/javascript">
	<?php if(isset($_GET['open'])){?>
		$('#ViewFileData').modal('show');
	<?php }?>
	$(document).ready(function(){
		$(document).on('click','.updateValuations',function(){
			$('.loadingDiv').show();
			var fileid = $(this).data('fileid');
			var propertyid = $(this).data('propertyid');
			$.ajax({
				data : {fileid : fileid,propertyid: propertyid},
				url : '/s/admin/update-valuations',
				type  : 'post',
				success:function(resp){
					$('#AppendValuationModal').html(resp);
					$('#ValuationModal').modal('show');
					$('.loadingDiv').hide();
				},
				error:function(){
					alert('Error');
				}
			})
		})
	})
</script>
@stop






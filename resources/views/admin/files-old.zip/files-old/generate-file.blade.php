@extends('layouts.adminLayout.backendLayout')
@section('content')
<?php use App\FileDropdown; use App\Employee; use App\File;?>
<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-head">
            <div class="page-title">
                <h1>File's Management </h1>
            </div>
        </div>
        <ul class="page-breadcrumb breadcrumb">
            <li>
                <a href="{!! action('AdminController@dashboard') !!}">Dashboard</a>
                <i class="fa fa-circle"></i>
            </li>
            <li>
                <a href="{{ action('FileController@files') }}">Files</a>
            </li>
        </ul>
        <div class="row" id="RemoveIfTypeChange">
            <div class="col-md-12 ">
                <div class="portlet blue-hoki box ">
				    <div class="portlet-title">
				        <div class="caption">
				            <i class="fa fa-gift"></i>{{$title}}
				        </div>
				    </div>
				    <div class="portlet-body form">
				        <form  class="form-horizontal" method="post" action="{{url('/s/admin/generate-file/'.$clientdetail->id)}}" enctype="multipart/form-data" autocomplete="off">@csrf
				        	<div class="form-body">
				                <div class="row">
				                	@if(isset($_GET['fileid']) && is_numeric($_GET['fileid']))
						                <input type="hidden" name="old_file" value="{{$_GET['fileid']}}">
						            @endif
					                <div class="clearfix"></div>
				                	<div class="form-group col-md-6">
					                    <label class="col-md-6 control-label">Client Name :</label>
					                    <div class="col-md-6">
					                        <p style="margin-top:8px;">{{$clientdetail->name}}</p>
					                    </div>
					                </div>
					                <div class="form-group col-md-6">
					                    <label class="col-md-6 control-label">Mobile :</label>
					                    <div class="col-md-6">
					                        <p style="margin-top:8px;">{{$clientdetail->mobile}}</p>
					                    </div>
					                </div>
					                <div class="clearfix"></div>
					                <div class="form-group col-md-6">
					                    <label class="col-md-6 control-label">PAN :</label>
					                    <div class="col-md-6">
					                        <p style="margin-top:8px;">{{$clientdetail->pan}}</p>
					                    </div>
					                </div>
					                <div class="form-group col-md-6">
					                	<?php $facilities = FileDropdown::getfiledropdown('facility'); ?>
					                    <label class="col-md-6 control-label">Type of Facility:</label>
					                    <div class="col-md-6">
					                        <select name="facility_type" class="selectbox" required> 
					                            <option value="">Select</option>
					                        	@foreach($facilities as $key => $facility)
					                            	<option value="{{$facility['value']}}" @if(!empty($filedetail['facility_type']) && $filedetail['facility_type'] == $facility['value']) selected @endif>{{$facility['value']}}</option>
					                            @endforeach
					                        </select>
					                    </div>
					                </div>
					                <div class="clearfix"></div>
					                <div class="form-group col-md-6">
					                	<?php $bms = Employee::getemployees('bm'); ?>
					                    <label class="col-md-6 control-label">Select Business Manager:</label>
					                    <div class="col-md-6">
					                        <select name="business_manager_id" class="selectbox" required> 
					                            <option value="">Select</option>
					                        	@foreach($bms as $key => $bm)
					                            	<option value="{{$bm['id']}}" @if(!empty($filedetail['business_manager_id']) && $filedetail['business_manager_id'] == $bm['id']) selected @endif>{{$bm['name']}} - {{$bm['emptype']}}</option>
					                            @endforeach
					                        </select>
					                    </div>
					                </div>
					            	<?php $employees = Employee::getemployees('all'); ?>
					                <div class="form-group col-md-6">
					                    <label class="col-md-6 control-label">Select Sales Manager:</label>
					                    <div class="col-md-6">
					                        <select name="sales_manager_id" class="selectbox" required> 
					                            <option value="">Select</option>
					                        	@foreach($employees as $key => $emp)
					                            	<option value="{{$emp['id']}}" @if(!empty($filedetail['sales_manager_id']) && $filedetail['sales_manager_id'] == $emp['id']) selected @endif>{{$emp['name']}} - {{$emp['emptype']}}</option>
					                            @endforeach
					                        </select>
					                    </div>
					                </div>
					                <div class="clearfix"></div>
					                <div class="form-group col-md-6">
					                    <label class="col-md-6 control-label">Select Sales Executive:</label>
					                    <div class="col-md-6">
					                        <select name="sales_executive_id" class="selectbox" required> 
					                            <option value="">Select</option>
					                        	@foreach($employees as $key => $emp)
					                            	<option value="{{$emp['id']}}" @if(!empty($filedetail['sales_executive_id']) && $filedetail['sales_executive_id'] == $emp['id']) selected @endif>{{$emp['name']}} - {{$emp['emptype']}}</option>
					                            @endforeach
					                        </select>
					                    </div>
					                </div>
					                <div class="form-group col-md-6">
					                    <label class="col-md-6 control-label">Select Operation Manager :</label>
					                    <div class="col-md-6">
					                        <select name="operation_manager_id" class="selectbox" required> 
					                            <option value="">Select</option>
					                        	@foreach($employees as $key => $emp)
					                            	<option value="{{$emp['id']}}" @if(!empty($filedetail['operation_manager_id']) && $filedetail['operation_manager_id'] == $emp['id']) selected @endif>{{$emp['name']}} - {{$emp['emptype']}}</option>
					                            @endforeach
					                        </select>
					                    </div>
					                </div>
					                <div class="clearfix"></div>
					                <div class="form-group col-md-6">
					                    <label class="col-md-6 control-label">Select Operation Executive :</label>
					                    <div class="col-md-6">
					                        <select name="operation_executive_id" class="selectbox" required> 
					                            <option value="">Select</option>
					                        	@foreach($employees as $key => $emp)
					                            	<option value="{{$emp['id']}}" @if(!empty($filedetail['operation_executive_id']) && $filedetail['operation_executive_id'] == $emp['id']) selected @endif>{{$emp['name']}} - {{$emp['emptype']}}</option>
					                            @endforeach
					                        </select>
					                    </div>
					                </div>
					                <div class="form-group col-md-6">
					                    <label class="col-md-6 control-label">Select Source :</label>
					                    <div class="col-md-6">
					                        <select name="source" class="selectbox" required> 
					                            <option value="">Select</option>
					                        	@foreach($employees as $key => $emp)
					                            	<option value="{{$emp['id']}}" @if(!empty($filedetail['source']) && $filedetail['source'] == $emp['id']) selected @endif>{{$emp['name']}} - {{$emp['emptype']}}</option>
					                            @endforeach
					                        </select>
					                    </div>
					                </div>
					                <div class="clearfix"></div>
					                <div class="form-group col-md-6">
					                    <label class="col-md-6 control-label">Select Type :</label>
					                    <div class="col-md-6">
					                        <select name="file_type" class="selectbox getFiletype" required> 
					                            <option value="">Select</option>
					                        	<option value="direct" @if(!empty($filedetail['file_type']) && $filedetail['file_type'] == "direct") selected @endif>Direct</option>
					                        	<option value="indirect" @if(!empty($filedetail['file_type']) && $filedetail['file_type'] == "indirect") selected @endif>Indirect</option>
					                        </select>
					                    </div>
					                </div>
					                <div id="Appendcrm">
					                	@if(!empty($filedetail['file_type']) && $filedetail['file_type'] == "indirect")
					                	<div class="form-group col-md-6">
						                    <label class="col-md-6 control-label">Channel Relation Manager :</label>
						                    <div class="col-md-6">
						                        <select name="crm_id" class="selectbox" required>
						                            <option value="">Select</option>';
						                            @foreach($employees as $key => $emp)
				                                        <option value="{{$emp['id']}}" @if(!empty($filedetail['crm_id']) && $filedetail['crm_id'] == $emp['id']) selected @endif>{{$emp['name']}} - {{$emp['emptype']}}</option>
				                                    @endforeach
						                        </select>
						                    </div>
				                		</div>
                                		<div class="clearfix"></div>
                                		<div class="form-group col-md-6">
						                    <label class="col-md-6 control-label">Select Channel Partner :</label>
						                    <div class="col-md-6">
						                        <select name="channel_partner_id" class="selectbox" required>
						                            <option value="">Select</option>';
						                            @foreach($getpartners as $key => $partner)
				                                        <option value="{{$partner['id']}}" @if(!empty($filedetail['channel_partner_id']) && $filedetail['channel_partner_id'] == $partner['id']) selected @endif>{{$partner['name'] }} - {{$partner['type']}}</option>
				                                    @endforeach
						                        </select>
						                    </div>
						                </div>
                                		@endif
					                </div>
				                </div>
				            </div>
				            <div class="form-actions right1 text-center">
				                <button class="btn green" type="submit">Procced & Generate File Number</button>
				            </div>
				        </form>
					</div>
				</div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('change','.getFiletype',function(){
			var type = $(this).val();
			if(type =="indirect"){
				$('.loadingDiv').show();
				$.ajax({
					data : {type :type},
					url : '/s/admin/append-crm',
					type : 'post',
					success:function(resp){
						$('#Appendcrm').html(resp);
						$('.loadingDiv').hide();
					},
					error:function(){}
				})
			}else{
				$('#Appendcrm').html('');
			}
		});
	})
</script>
@stop
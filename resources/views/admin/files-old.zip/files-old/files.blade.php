@extends('layouts.adminLayout.backendLayout')
@section('content')
<style>
.table-scrollable table tbody tr td{
    vertical-align: middle;
}
</style>
<?php use App\Employee; ?>
<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-head">
            <div class="page-title">
                <h1>File's Management</h1>
            </div>
        </div>
        <ul class="page-breadcrumb breadcrumb">
            <li>
                <a href="{!! action('AdminController@dashboard') !!}">Dashboard</a>
            </li>
        </ul>
         @if(Session::has('flash_message_error'))
            <div role="alert" class="alert alert-danger alert-dismissible fade in"> <button aria-label="Close" data-dismiss="alert" style="text-indent: 0;" class="close" type="button"><span aria-hidden="true"></span></button> <strong>Error!</strong> {!! session('flash_message_error') !!} </div>
        @endif
        @if(Session::has('flash_message_success'))
            <div role="alert" class="alert alert-success alert-dismissible fade in"> <button aria-label="Close" data-dismiss="alert" style="text-indent: 0;" class="close" type="button"><span aria-hidden="true"></span></button> <strong>Success!</strong> {!! session('flash_message_success') !!} </div>
        @endif
        <div class="row">
            <div class="col-md-12">
                <div class="portlet light">
                    <div class="portlet-title">
                        <div class="caption">
                            <span class="caption-subject font-green-sharp bold uppercase">{{$heading}}</span>
                        </div>
                    </div>
                    <div class="portlet-body">
                        @if($addfile=="yes")
                             <div class="table-toolbar">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="btn-group">
                                           <a href="{{action('FileController@addFile')}}" class="btn btn-primary">Add File</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endif
                        <div class="table-container">
                            <table class="table table-striped table-bordered table-hover" id="datatable_ajax">
                                <thead>
                                    <tr role="row" class="heading">
                                        <th width="10%">
                                            File No
                                        </th>
                                        <th width="15%">
                                            Faility Type
                                        </th>
                                        <th>
                                            Name
                                        </th>
                                        <th>
                                           Business Manager
                                        </th>
                                        <th>
                                          Sales Manger
                                        </th>
                                        <th>
                                          Sales Executive
                                        </th>
                                        <th>
                                          Source
                                        </th>
                                        <th width="15%">
                                            Actions
                                        </th>
                                    </tr>
                                    <tr role="row" class="filter">
                                        <td><input type="text" class="form-control form-filter input-sm" name="file_no" placeholder="File No"></td>
                                        <td><input type="text" class="form-control form-filter input-sm" name="facility_type" placeholder="Facility Type"></td>
                                        <td><input type="text" class="form-control form-filter input-sm" name="name" placeholder="Client Name"></td>
                                        <?php $getemps = Employee::getemployees('bm') ?>
                                        <td>
                                            <select class="form-control form-filter input-sm" name="business_manager_id">
                                                <option value="">Select</option>
                                                @foreach($getemps as $emp)
                                                    <option value="{{$emp['id']}}">{{$emp['name']}}</option>
                                                @endforeach
                                            </select>
                                        </td>
                                        <?php $getallemps = Employee::getemployees('all') ?>
                                        <td>
                                            <select class="form-control form-filter input-sm" name="sales_manager_id">
                                                <option value="">Select</option>
                                                @foreach($getallemps as $getemp)
                                                    <option value="{{$getemp['id']}}">{{$getemp['name']}}</option>
                                                @endforeach
                                            </select>
                                        </td>
                                        <td>
                                            <select class="form-control form-filter input-sm" name="sales_executive_id">
                                                <option value="">Select</option>
                                                @foreach($getallemps as $getemp)
                                                    <option value="{{$getemp['id']}}">{{$getemp['name']}}</option>
                                                @endforeach
                                            </select>
                                        </td>
                                        <td>
                                            <select class="form-control form-filter input-sm" name="source">
                                                <option value="">Select</option>
                                                @foreach($getallemps as $getemp)
                                                    <option value="{{$getemp['id']}}">{{$getemp['name']}}</option>
                                                @endforeach
                                            </select>
                                        </td>
                                        <td>
                                            <div class="margin-bottom-5">
                                                <button class="btn btn-sm yellow filter-submit margin-bottom"><i title="Search" class="fa fa-search"></i></button>
                                                <button class="btn btn-sm red filter-cancel"><i title="Reset" class="fa fa-refresh"></i></button>
                                            </div>
                                        </td>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@stop






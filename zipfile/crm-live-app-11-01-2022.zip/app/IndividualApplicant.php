<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IndividualApplicant extends Model
{
    //
}

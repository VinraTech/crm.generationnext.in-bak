<div align="center" style="margin-top:100px;">
    <img src="<?php echo e(asset('images/404.png')); ?>">
</div>
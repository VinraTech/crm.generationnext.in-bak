<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NonindividualPartner extends Model
{
    //
}

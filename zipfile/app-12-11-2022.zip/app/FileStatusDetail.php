<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FileStatusDetail extends Model
{
    //
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PartialFile extends Model
{
    //
}

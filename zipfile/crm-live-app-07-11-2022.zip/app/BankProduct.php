<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BankProduct extends Model
{
    protected $table = "banker_product";
}

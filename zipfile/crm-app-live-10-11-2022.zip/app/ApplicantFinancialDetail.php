<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ApplicantFinancialDetail extends Model
{
    //
}
